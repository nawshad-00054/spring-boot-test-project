package com.mytestp.testp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestpApplicationTests {

	@Test
	void contextLoads() {
	}

}
